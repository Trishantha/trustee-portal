/**
 * Notification Scheduler Service
 * Phase 6: Automated Notifications & Reminders
 */

const db = require('../config/database');
const emailService = require('./email');
const usageTracker = require('./usage-tracker');

class NotificationScheduler {
    constructor() {
        this.isRunning = false;
        this.intervals = [];
    }

    /**
     * Start all scheduled tasks
     */
    start() {
        if (this.isRunning) return;
        
        console.log('🔄 Starting notification scheduler...');
        this.isRunning = true;

        // Check trial expirations daily
        this.intervals.push(setInterval(() => {
            this.checkTrialExpirations();
        }, 24 * 60 * 60 * 1000)); // 24 hours

        // Check limit warnings hourly
        this.intervals.push(setInterval(() => {
            this.checkLimitWarnings();
        }, 60 * 60 * 1000)); // 1 hour

        // Check past due subscriptions daily
        this.intervals.push(setInterval(() => {
            this.checkPastDueSubscriptions();
        }, 24 * 60 * 60 * 1000)); // 24 hours

        // Run immediately on start
        this.checkTrialExpirations();
        this.checkLimitWarnings();
        this.checkPastDueSubscriptions();

        console.log('✅ Notification scheduler started');
    }

    /**
     * Stop all scheduled tasks
     */
    stop() {
        this.intervals.forEach(clearInterval);
        this.intervals = [];
        this.isRunning = false;
        console.log('⏹️ Notification scheduler stopped');
    }

    /**
     * Check for trial expirations and send reminders
     */
    async checkTrialExpirations() {
        try {
            console.log('📧 Checking trial expirations...');

            // Get trials expiring in 3 days
            const trialsExpiring3Days = await db.all(`
                SELECT o.*, p.name as plan_name
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'trial'
                AND o.trial_ends_at <= datetime('now', '+3 days')
                AND o.trial_ends_at > datetime('now', '+2 days')
                AND o.id NOT IN (
                    SELECT DISTINCT organization_id FROM notifications 
                    WHERE type = 'trial_reminder_3day' AND created_at > datetime('now', '-7 days')
                )
            `);

            for (const org of trialsExpiring3Days) {
                await emailService.sendTrialExpirationReminder(org, 3);
                await this.createNotification(org.id, null, 'trial_reminder_3day', 
                    'Trial Expiring Soon', 
                    'Your trial will expire in 3 days.');
            }

            // Get trials expiring in 1 day
            const trialsExpiring1Day = await db.all(`
                SELECT o.*, p.name as plan_name
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'trial'
                AND o.trial_ends_at <= datetime('now', '+1 day')
                AND o.trial_ends_at > datetime('now')
                AND o.id NOT IN (
                    SELECT DISTINCT organization_id FROM notifications 
                    WHERE type = 'trial_reminder_1day' AND created_at > datetime('now', '-2 days')
                )
            `);

            for (const org of trialsExpiring1Day) {
                await emailService.sendTrialExpirationReminder(org, 1);
                await this.createNotification(org.id, null, 'trial_reminder_1day',
                    'Trial Expires Tomorrow',
                    'Your trial will expire tomorrow.');
            }

            console.log(`✅ Sent ${trialsExpiring3Days.length + trialsExpiring1Day.length} trial reminders`);
        } catch (error) {
            console.error('Check trial expirations error:', error);
        }
    }

    /**
     * Check for organizations approaching limits
     */
    async checkLimitWarnings() {
        try {
            console.log('📊 Checking limit warnings...');

            const warnings = await usageTracker.sendLimitWarnings();

            for (const warning of warnings) {
                // Get organization
                const org = await db.get(
                    'SELECT * FROM organizations WHERE id = ?',
                    [warning.organization_id]
                );

                if (org) {
                    await emailService.sendLimitWarning(
                        org,
                        warning.resource,
                        warning.current,
                        warning.limit,
                        warning.percentage
                    );

                    // Create in-app notification
                    const admins = await db.all(`
                        SELECT u.id
                        FROM organization_members om
                        JOIN users u ON om.user_id = u.id
                        WHERE om.organization_id = ? AND om.role IN ('owner', 'admin')
                    `, [warning.organization_id]);

                    for (const admin of admins) {
                        await this.createNotification(
                            warning.organization_id,
                            admin.id,
                            'limit_warning',
                            `${warning.resource} limit warning`,
                            `You are using ${warning.percentage}% of your ${warning.resource} limit.`
                        );
                    }
                }
            }

            console.log(`✅ Sent ${warnings.length} limit warnings`);
        } catch (error) {
            console.error('Check limit warnings error:', error);
        }
    }

    /**
     * Check past due subscriptions
     */
    async checkPastDueSubscriptions() {
        try {
            console.log('💳 Checking past due subscriptions...');

            const pastDueOrgs = await db.all(`
                SELECT o.*, p.name as plan_name
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'past_due'
                AND o.updated_at < datetime('now', '-3 days')
                AND o.id NOT IN (
                    SELECT DISTINCT organization_id FROM notifications 
                    WHERE type = 'past_due_warning' AND created_at > datetime('now', '-7 days')
                )
            `);

            for (const org of pastDueOrgs) {
                // Get billing email
                const billingEmail = org.billing_email || org.email;
                
                // Send warning email
                const html = `
                    <h2>Payment Overdue</h2>
                    <p>Your payment for ${org.name} is 3+ days overdue.</p>
                    <p>Please update your payment method to avoid service suspension.</p>
                `;

                await emailService.sendEmail({
                    to: billingEmail,
                    subject: `Payment Overdue - ${org.name}`,
                    html
                });

                // Create notifications for admins
                const admins = await db.all(`
                    SELECT u.id
                    FROM organization_members om
                    JOIN users u ON om.user_id = u.id
                    WHERE om.organization_id = ? AND om.role IN ('owner', 'admin')
                `, [org.id]);

                for (const admin of admins) {
                    await this.createNotification(
                        org.id,
                        admin.id,
                        'past_due_warning',
                        'Payment Overdue',
                        'Your payment is 3+ days overdue. Please update your payment method.'
                    );
                }
            }

            console.log(`✅ Sent ${pastDueOrgs.length} past due warnings`);
        } catch (error) {
            console.error('Check past due subscriptions error:', error);
        }
    }

    /**
     * Create in-app notification
     */
    async createNotification(organizationId, userId, type, title, message, link = null) {
        try {
            await db.run(`
                INSERT INTO notifications (organization_id, user_id, type, title, message, link, created_at)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            `, [organizationId, userId, type, title, message, link]);
        } catch (error) {
            console.error('Create notification error:', error);
        }
    }

    /**
     * Send immediate notification (not scheduled)
     */
    async sendImmediateNotification(organizationId, userIds, type, title, message, link = null) {
        try {
            // Create in-app notifications
            for (const userId of userIds) {
                await this.createNotification(organizationId, userId, type, title, message, link);
            }

            // Send emails if appropriate
            const users = await db.all(
                'SELECT email, first_name FROM users WHERE id IN (' + userIds.join(',') + ')'
            );

            for (const user of users) {
                await emailService.sendEmail({
                    to: user.email,
                    subject: title,
                    html: `<h2>${title}</h2><p>${message}</p>`
                });
            }
        } catch (error) {
            console.error('Send immediate notification error:', error);
        }
    }
}

// Create singleton instance
const scheduler = new NotificationScheduler();

module.exports = scheduler;
