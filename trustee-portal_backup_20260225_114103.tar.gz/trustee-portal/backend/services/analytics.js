/**
 * Analytics Service
 * Phase 5: Platform Admin Dashboard - Revenue Analytics, Churn Tracking, Growth Metrics
 */

const db = require('../config/database');

class AnalyticsService {
    /**
     * Get revenue analytics
     */
    async getRevenueAnalytics(startDate, endDate) {
        try {
            // Monthly revenue breakdown
            const monthlyRevenue = await db.all(`
                SELECT 
                    strftime('%Y-%m', o.created_at) as month,
                    p.name as plan_name,
                    COUNT(o.id) as new_organizations,
                    SUM(p.price_monthly) as monthly_recurring_revenue
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.created_at >= ? AND o.created_at <= ?
                AND o.subscription_status IN ('trial', 'active')
                GROUP BY strftime('%Y-%m', o.created_at), p.name
                ORDER BY month DESC
            `, [startDate, endDate]);

            // Total MRR (Monthly Recurring Revenue)
            const mrr = await db.get(`
                SELECT SUM(p.price_monthly) as total_mrr,
                       SUM(p.price_yearly / 12) as estimated_arr
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'active'
            `);

            // Revenue by plan
            const revenueByPlan = await db.all(`
                SELECT 
                    p.name as plan_name,
                    COUNT(o.id) as organization_count,
                    SUM(p.price_monthly) as monthly_revenue,
                    ROUND(AVG(p.price_monthly), 2) as avg_revenue_per_org
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'active'
                GROUP BY p.id
                ORDER BY monthly_revenue DESC
            `);

            return {
                total_mrr: mrr?.total_mrr || 0,
                estimated_arr: mrr?.estimated_arr || 0,
                monthly_breakdown: monthlyRevenue,
                by_plan: revenueByPlan
            };
        } catch (error) {
            console.error('Get revenue analytics error:', error);
            return null;
        }
    }

    /**
     * Get churn analytics
     */
    async getChurnAnalytics(days = 90) {
        try {
            const startDate = new Date();
            startDate.setDate(startDate.getDate() - days);

            // Cancelled organizations
            const cancellations = await db.all(`
                SELECT 
                    o.id,
                    o.name,
                    o.slug,
                    p.name as plan_name,
                    p.price_monthly,
                    o.created_at as signup_date,
                    o.updated_at as cancellation_date,
                    julianday(o.updated_at) - julianday(o.created_at) as lifetime_days
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'cancelled'
                AND o.updated_at >= ?
                ORDER BY o.updated_at DESC
            `, [startDate.toISOString()]);

            // Calculate churn metrics
            const totalAtStart = await db.get(`
                SELECT COUNT(*) as count 
                FROM organizations 
                WHERE created_at < ? 
                AND (subscription_status != 'cancelled' OR updated_at > ?)
            `, [startDate.toISOString(), startDate.toISOString()]);

            const churnRate = totalAtStart.count > 0 
                ? (cancellations.length / totalAtStart.count) * 100 
                : 0;

            // Revenue churn
            const revenueChurn = cancellations.reduce((sum, c) => sum + (c.price_monthly || 0), 0);

            // Churn by plan
            const churnByPlan = await db.all(`
                SELECT 
                    p.name as plan_name,
                    COUNT(o.id) as cancellations,
                    SUM(p.price_monthly) as lost_revenue
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'cancelled'
                AND o.updated_at >= ?
                GROUP BY p.id
            `, [startDate.toISOString()]);

            // Average lifetime before cancellation
            const avgLifetime = cancellations.length > 0
                ? cancellations.reduce((sum, c) => sum + (c.lifetime_days || 0), 0) / cancellations.length
                : 0;

            return {
                period_days: days,
                total_cancellations: cancellations.length,
                churn_rate_percent: Math.round(churnRate * 100) / 100,
                revenue_churn_monthly: revenueChurn,
                avg_lifetime_days: Math.round(avgLifetime),
                churn_by_plan: churnByPlan,
                cancellations: cancellations.slice(0, 50) // Top 50 recent
            };
        } catch (error) {
            console.error('Get churn analytics error:', error);
            return null;
        }
    }

    /**
     * Get growth metrics
     */
    async getGrowthMetrics(days = 90) {
        try {
            const startDate = new Date();
            startDate.setDate(startDate.getDate() - days);

            // Daily signups
            const dailySignups = await db.all(`
                SELECT 
                    date(created_at) as date,
                    COUNT(*) as new_organizations
                FROM organizations
                WHERE created_at >= ?
                GROUP BY date(created_at)
                ORDER BY date
            `, [startDate.toISOString()]);

            // Signups by plan
            const signupsByPlan = await db.all(`
                SELECT 
                    p.name as plan_name,
                    COUNT(o.id) as signups
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.created_at >= ?
                GROUP BY p.id
            `, [startDate.toISOString()]);

            // Trial to paid conversion
            const trialConversion = await db.all(`
                SELECT 
                    p.name as plan_name,
                    COUNT(CASE WHEN o.subscription_status = 'active' THEN 1 END) as converted,
                    COUNT(CASE WHEN o.subscription_status = 'trial' THEN 1 END) as still_in_trial,
                    COUNT(CASE WHEN o.subscription_status = 'cancelled' THEN 1 END) as cancelled,
                    COUNT(*) as total
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.created_at >= ?
                GROUP BY p.id
            `, [startDate.toISOString()]);

            // Calculate conversion rate
            const totalTrials = trialConversion.reduce((sum, t) => sum + t.total, 0);
            const totalConverted = trialConversion.reduce((sum, t) => sum + t.converted, 0);
            const conversionRate = totalTrials > 0 ? (totalConverted / totalTrials) * 100 : 0;

            // Net growth (new - cancelled)
            const newOrgs = await db.get(`
                SELECT COUNT(*) as count FROM organizations WHERE created_at >= ?
            `, [startDate.toISOString()]);

            const cancelledOrgs = await db.get(`
                SELECT COUNT(*) as count FROM organizations 
                WHERE subscription_status = 'cancelled' 
                AND updated_at >= ?
            `, [startDate.toISOString()]);

            return {
                period_days: days,
                daily_signups: dailySignups,
                signups_by_plan: signupsByPlan,
                total_new_organizations: newOrgs.count,
                total_cancellations: cancelledOrgs.count,
                net_growth: newOrgs.count - cancelledOrgs.count,
                trial_conversion: {
                    rate_percent: Math.round(conversionRate * 100) / 100,
                    by_plan: trialConversion
                }
            };
        } catch (error) {
            console.error('Get growth metrics error:', error);
            return null;
        }
    }

    /**
     * Get organization health metrics
     */
    async getOrganizationHealth() {
        try {
            const now = new Date().toISOString();

            // Organizations by status
            const statusBreakdown = await db.all(`
                SELECT 
                    subscription_status,
                    COUNT(*) as count,
                    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM organizations), 2) as percentage
                FROM organizations
                GROUP BY subscription_status
            `);

            // At-risk organizations (trial ending in 7 days)
            const atRisk = await db.all(`
                SELECT 
                    o.id, o.name, o.slug, o.trial_ends_at, p.name as plan_name
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'trial'
                AND o.trial_ends_at <= datetime('now', '+7 days')
                AND o.trial_ends_at > datetime('now')
                ORDER BY o.trial_ends_at
            `);

            // Past due organizations
            const pastDue = await db.all(`
                SELECT 
                    o.id, o.name, o.slug, o.updated_at, p.name as plan_name, p.price_monthly
                FROM organizations o
                JOIN subscription_plans p ON o.plan_id = p.id
                WHERE o.subscription_status = 'past_due'
                ORDER BY o.updated_at DESC
            `);

            // Most active organizations (by audit log activity)
            const mostActive = await db.all(`
                SELECT 
                    o.id, o.name, o.slug,
                    COUNT(al.id) as activity_count
                FROM organizations o
                LEFT JOIN audit_log al ON o.id = al.organization_id
                AND al.created_at >= datetime('now', '-30 days')
                GROUP BY o.id
                ORDER BY activity_count DESC
                LIMIT 20
            `);

            // Organizations with no activity (inactive)
            const inactive = await db.all(`
                SELECT 
                    o.id, o.name, o.slug, o.created_at, o.last_login_at
                FROM organizations o
                WHERE o.id NOT IN (
                    SELECT DISTINCT organization_id 
                    FROM audit_log 
                    WHERE created_at >= datetime('now', '-30 days')
                )
                AND o.subscription_status IN ('trial', 'active')
                ORDER BY o.created_at DESC
                LIMIT 20
            `);

            return {
                status_breakdown: statusBreakdown,
                at_risk_count: atRisk.length,
                at_risk_organizations: atRisk,
                past_due_count: pastDue.length,
                past_due_organizations: pastDue,
                most_active: mostActive,
                inactive_organizations: inactive
            };
        } catch (error) {
            console.error('Get organization health error:', error);
            return null;
        }
    }

    /**
     * Get dashboard summary for platform admin
     */
    async getDashboardSummary() {
        try {
            const now = new Date();
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

            const [
                totalStats,
                revenue,
                churn,
                growth,
                health
            ] = await Promise.all([
                this.getTotalStats(),
                this.getRevenueAnalytics(thirtyDaysAgo.toISOString(), now.toISOString()),
                this.getChurnAnalytics(30),
                this.getGrowthMetrics(30),
                this.getOrganizationHealth()
            ]);

            return {
                timestamp: now.toISOString(),
                totals: totalStats,
                revenue: revenue,
                churn: churn,
                growth: growth,
                health: health
            };
        } catch (error) {
            console.error('Get dashboard summary error:', error);
            return null;
        }
    }

    /**
     * Get basic total statistics
     */
    async getTotalStats() {
        try {
            const [
                totalOrgs,
                totalUsers,
                activeSubscriptions,
                trialOrganizations
            ] = await Promise.all([
                db.get('SELECT COUNT(*) as count FROM organizations'),
                db.get('SELECT COUNT(*) as count FROM users'),
                db.get("SELECT COUNT(*) as count FROM organizations WHERE subscription_status = 'active'"),
                db.get("SELECT COUNT(*) as count FROM organizations WHERE subscription_status = 'trial'")
            ]);

            return {
                total_organizations: totalOrgs.count,
                total_users: totalUsers.count,
                active_subscriptions: activeSubscriptions.count,
                trial_organizations: trialOrganizations.count
            };
        } catch (error) {
            console.error('Get total stats error:', error);
            return null;
        }
    }
}

module.exports = new AnalyticsService();
