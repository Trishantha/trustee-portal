const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/database');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.use(authenticate);

// GET /api/users - Get all users
router.get('/', async (req, res) => {
    try {
        const { role, search = '' } = req.query;

        let sql = `
            SELECT id, email, first_name, last_name, role, avatar, 
                   department, phone, is_active, last_login, created_at
            FROM users
            WHERE 1=1
        `;
        const params = [];

        if (role) {
            sql += ' AND role = ?';
            params.push(role);
        }

        if (search) {
            sql += ' AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)';
            params.push(`%${search}%`, `%${search}%`, `%${search}%`);
        }

        sql += ' ORDER BY first_name, last_name';

        const users = await db.all(sql, params);
        res.json({ users });
    } catch (error) {
        console.error('Get users error:', error);
        res.status(500).json({ error: 'Failed to fetch users.' });
    }
});

// GET /api/users/:id - Get single user
router.get('/:id', async (req, res) => {
    try {
        const user = await db.get(
            `SELECT id, email, first_name, last_name, role, avatar, 
                    department, phone, bio, is_active, last_login, created_at
             FROM users WHERE id = ?`,
            [req.params.id]
        );

        if (!user) {
            return res.status(404).json({ error: 'User not found.' });
        }

        // Get committee memberships
        const committees = await db.all(
            `SELECT c.id, c.name, c.color_theme, cm.role_in_committee
             FROM committees c
             JOIN committee_members cm ON c.id = cm.committee_id
             WHERE cm.user_id = ?`,
            [req.params.id]
        );

        // Get task stats
        const taskStats = await db.get(
            `SELECT 
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
                COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as in_progress,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
                COUNT(*) as total
             FROM tasks WHERE assigned_to = ?`,
            [req.params.id]
        );

        res.json({ user: { ...user, committees, taskStats } });
    } catch (error) {
        console.error('Get user error:', error);
        res.status(500).json({ error: 'Failed to fetch user.' });
    }
});

// POST /api/users - Create user (admin only)
router.post('/', requireAdmin, async (req, res) => {
    try {
        const { email, password, firstName, lastName, role = 'trustee', department, phone } = req.body;

        if (!email || !password || !firstName || !lastName) {
            return res.status(400).json({ error: 'Missing required fields.' });
        }

        // Check if exists
        const existing = await db.get('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
        if (existing) {
            return res.status(409).json({ error: 'User with this email already exists.' });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const result = await db.run(
            `INSERT INTO users (email, password, first_name, last_name, role, department, phone, avatar)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                email.toLowerCase(),
                hashedPassword,
                firstName,
                lastName,
                role,
                department,
                phone,
                `${firstName[0]}${lastName[0]}`.toUpperCase()
            ]
        );

        const user = await db.get(
            `SELECT id, email, first_name, last_name, role, avatar, department, phone, created_at
             FROM users WHERE id = ?`,
            [result.id]
        );

        res.status(201).json({ message: 'User created successfully', user });
    } catch (error) {
        console.error('Create user error:', error);
        res.status(500).json({ error: 'Failed to create user.' });
    }
});

// PUT /api/users/:id - Update user
router.put('/:id', requireAdmin, async (req, res) => {
    try {
        const { firstName, lastName, role, department, phone, isActive } = req.body;

        await db.run(
            `UPDATE users 
             SET first_name = ?, last_name = ?, role = ?, department = ?, phone = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
             WHERE id = ?`,
            [firstName, lastName, role, department, phone, isActive, req.params.id]
        );

        const user = await db.get(
            `SELECT id, email, first_name, last_name, role, avatar, department, phone, is_active, updated_at
             FROM users WHERE id = ?`,
            [req.params.id]
        );

        res.json({ message: 'User updated successfully', user });
    } catch (error) {
        console.error('Update user error:', error);
        res.status(500).json({ error: 'Failed to update user.' });
    }
});

// POST /api/users/:id/reset-password - Reset user password (admin only)
router.post('/:id/reset-password', requireAdmin, async (req, res) => {
    try {
        const { newPassword } = req.body;

        if (!newPassword) {
            return res.status(400).json({ error: 'New password is required.' });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(newPassword, salt);

        await db.run(
            'UPDATE users SET password = ? WHERE id = ?',
            [hashedPassword, req.params.id]
        );

        res.json({ message: 'Password reset successfully.' });
    } catch (error) {
        console.error('Reset password error:', error);
        res.status(500).json({ error: 'Failed to reset password.' });
    }
});

// DELETE /api/users/:id - Delete user
router.delete('/:id', requireAdmin, async (req, res) => {
    try {
        await db.run('DELETE FROM users WHERE id = ?', [req.params.id]);
        res.json({ message: 'User deleted successfully.' });
    } catch (error) {
        console.error('Delete user error:', error);
        res.status(500).json({ error: 'Failed to delete user.' });
    }
});

module.exports = router;
