# Trustee Portal Backend API

A production-ready Node.js/Express backend with SQLite database for the Trustee Portal governance platform.

## Features

- **Authentication & Authorization**: JWT-based auth with role-based access control (Admin, Chair, Trustee)
- **RESTful API**: Full CRUD operations for all entities
- **SQLite Database**: Self-contained, serverless database (no MySQL setup required)
- **Security**: Password hashing with bcrypt, CORS protection, input validation
- **Modular Architecture**: Separate routes, models, and middleware

## Tech Stack

- Node.js 18+
- Express.js
- SQLite3 (better-sqlite3)
- JWT (jsonwebtoken)
- bcryptjs
- CORS
- dotenv

## Quick Start

### 1. Install Dependencies

```bash
cd backend
npm install
```

### 2. Initialize Database

```bash
npm run db:init
# or
node database/init.js
```

This creates:
- SQLite database at `database/trustee_portal.db`
- 17 tables for all entities
- Seed data with default users

### 3. Configure Environment

```bash
cp .env.example .env
# Edit .env with your settings
```

### 4. Start Server

```bash
# Development mode with auto-reload
npm run dev

# Production mode
npm start
```

Server runs on `http://localhost:3001`

## Default Login Credentials

| Role  | Email                        | Password   |
|-------|------------------------------|------------|
| Admin | admin@trusteeportal.org      | admin123   |
| Chair | chair@trusteeportal.org      | chair123   |
| Trustee| trustee@trusteeportal.org   | trustee123 |

## API Endpoints

### Authentication
```
POST   /api/auth/login          - Login
POST   /api/auth/register       - Register user
GET    /api/auth/me             - Get current user
PUT    /api/auth/profile        - Update profile
POST   /api/auth/change-password - Change password
```

### Users (Admin only)
```
GET    /api/users               - List users
GET    /api/users/:id           - Get user
POST   /api/users               - Create user
PUT    /api/users/:id           - Update user
DELETE /api/users/:id           - Delete user
```

### Committees
```
GET    /api/committees          - List committees
GET    /api/committees/:id      - Get committee details
POST   /api/committees          - Create committee (Admin/Chair)
PUT    /api/committees/:id      - Update committee
POST   /api/committees/:id/members      - Add member
DELETE /api/committees/:id/members/:userId - Remove member
DELETE /api/committees/:id      - Delete committee
```

### Meetings
```
GET    /api/meetings            - List meetings
GET    /api/meetings/:id        - Get meeting details
POST   /api/meetings            - Create meeting
PUT    /api/meetings/:id        - Update meeting
PUT    /api/meetings/:id/rsvp   - RSVP to meeting
DELETE /api/meetings/:id        - Delete meeting
```

### Tasks
```
GET    /api/tasks               - List tasks
GET    /api/tasks/:id           - Get task
POST   /api/tasks               - Create task (Admin/Chair)
PUT    /api/tasks/:id           - Update task
POST   /api/tasks/:id/complete  - Complete task
DELETE /api/tasks/:id           - Delete task
```

### Recruitment
```
GET    /api/recruitment/jobs              - List job openings
GET    /api/recruitment/jobs/:id          - Get job details
POST   /api/recruitment/jobs              - Create job
PUT    /api/recruitment/jobs/:id          - Update job
POST   /api/recruitment/jobs/:id/close    - Close job
DELETE /api/recruitment/jobs/:id          - Delete job

GET    /api/recruitment/applications      - List applications
POST   /api/recruitment/apply             - Submit application (Public)
PUT    /api/recruitment/applications/:id/status - Update status

GET    /api/recruitment/shortlisted       - Get shortlisted
PUT    /api/recruitment/shortlisted/:id/interview - Schedule interview
PUT    /api/recruitment/shortlisted/:id/score - Update score

GET    /api/recruitment/selected          - Get selected candidates
POST   /api/recruitment/selected          - Select candidate
```

### Dashboard
```
GET    /api/dashboard           - Get dashboard stats
GET    /api/dashboard/calendar  - Get calendar events
GET    /api/dashboard/activity  - Get recent activity
```

## Database Schema

### Core Tables
- `users` - Trustees, Chairs, Admins
- `committees` - Board committees
- `committee_members` - Committee memberships
- `meetings` - Board and committee meetings
- `meeting_attendees` - Meeting RSVPs
- `tasks` - Assigned tasks
- `documents` - Minutes and policies
- `messages` - Internal messaging

### Recruitment Tables
- `job_openings` - Job postings
- `applications` - Job applications
- `shortlisted_candidates` - Shortlisted applicants
- `biometric_verifications` - ID verification
- `selected_candidates` - Hired candidates

### System Tables
- `notifications` - User notifications
- `audit_log` - Activity logging
- `training_modules` - Training content
- `user_training` - Training progress

## Frontend Integration

The frontend API client is in `/js/api.js`. It provides:

```javascript
// Authentication
await authAPI.login(email, password);
await authAPI.getCurrentUser();

// Users
await usersAPI.getAll();
await usersAPI.create({ firstName, lastName, email, role });

// Committees
await committeesAPI.getAll();
await committeesAPI.create({ name, description, chairId });

// Recruitment
await recruitmentAPI.getJobs();
await recruitmentAPI.createJob({ title, department, ... });
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| PORT | 3001 | Server port |
| NODE_ENV | development | Environment mode |
| JWT_SECRET | - | JWT signing secret |
| JWT_EXPIRES_IN | 24h | Token expiration |
| CORS_ORIGIN | * | Allowed origins |

## Production Deployment

1. Set strong JWT_SECRET
2. Use environment variables, not .env file
3. Enable HTTPS
4. Set up proper CORS origins
5. Use PM2 for process management:

```bash
npm install -g pm2
pm2 start server.js --name trustee-portal
pm2 save
pm2 startup
```

## Scripts

```bash
npm start          # Start server
npm run dev        # Start with nodemon
npm run db:init    # Initialize database
npm run db:reset   # Reset database (creates fresh)
```

## Security Notes

- All passwords are hashed with bcrypt (10 rounds)
- JWT tokens expire after 24 hours
- Role-based access control on all sensitive endpoints
- CORS configured for frontend origin
- SQL injection protection via parameterized queries

## License

MIT
